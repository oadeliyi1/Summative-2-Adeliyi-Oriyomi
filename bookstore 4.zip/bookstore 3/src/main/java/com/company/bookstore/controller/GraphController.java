package com.company.bookstore.controller;

import java.util.*;

import com.company.bookstore.model.Publisher;
import com.company.bookstore.repository.PublisherRepository;
import org.springframework.*;
import org.springframework.beans.factory.annotation.Autowired;


public class GraphController {
    @Autowired
    PublisherRepository publisherRepository;
    PublisherController publisherController;

//    public Publisher findPublisherbyID(int id){
//
//        Optional<Publisher> publisher1 = publisherRepository.findById(id);
//
//
//
//
//      //  return
//
//
//
//    }




}


